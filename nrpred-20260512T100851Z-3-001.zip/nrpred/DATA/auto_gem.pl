#!/usr/bin/perl
for($numb=1;$numb<5;$numb++){
    print "---------->Generating $numb st MODEL<--------------\n\n";
    system "rm trainingset_*";
    system"sets.pl $numb";
    system "./svm_learn -z c -t 2 -g 3 trainingset_1.pat modeld_$numb";
}
