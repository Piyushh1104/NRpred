#!/usr/bin/perl
$file=$ARGV[0];
$num=$ARGV[1];
chomp($file);
chomp($num);
open(MAS,"$file");
while($line=<MAS>){
$label="-1";
    $c=0;
    chomp($line);
    #print "$line\n";
    @ss=split(/ +/,$line);
    if(($num==1) && ($ss[0]=~ /THR/)){
	$label="+1";
    }
if(($num==2) && ($ss[0]=~ /HNF/)){
	$label="+1";
    }
if(($num==3) && ($ss[0]=~ /EST/)){
	$label="+1";
    }
if(($num==4) && ($ss[0]=~ /FUS/)){
	$label="+1";
    }

    print "$label";
    for($a=1;$a<401;$a++){
	$c++;
	$sa=sprintf"%6.4f",$ss[$a];
	$sa=~ s/[\s]//g;
	print " $c:$sa";
    }
    print "\n";
 
}




