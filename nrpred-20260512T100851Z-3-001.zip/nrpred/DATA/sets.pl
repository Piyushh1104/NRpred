#!/usr/bin/perl
$num=$ARGV[0];
chomp($num);
system "./patter.pl set1 $num >> trainingset_1.pat";
system "./patter.pl set2 $num >> trainingset_1.pat";
system "./patter.pl set3 $num >> trainingset_1.pat";
system "./patter.pl set4 $num >> trainingset_1.pat";
system "./patter.pl set5 $num >> trainingset_1.pat";
